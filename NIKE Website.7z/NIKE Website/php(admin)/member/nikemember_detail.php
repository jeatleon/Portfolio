<html>
<head><title>Member Detail</title>
<link href="nikememberdesign.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="../phpmain.css" />
</head>
<body>
<?php include '../phpmain.php'; ?>
<div id="wrapper">

	<div id="left">
		<?php include("nikemembermenu.php"); ?>
	</div>
	
	<div id="right">

		<h1>Member Details</h1>

		<?php
		include ("dataconnectionnikemember.php");
		 if(isset($_GET['view']))
		{
			$memid = $_GET["memid"];
			$query = "SELECT * FROM member WHERE member_id = $memid";
			$result = mysqli_query($connect, $query);
			$row = mysqli_fetch_assoc($result);
		
		echo "<br><b>ID</b><br>";
		echo $row["member_id"]; 
		echo "<br><b>Email</b><br>";
		echo $row["member_email"]; 
		echo "<br><b>Name</b><br>";
		echo $row["member_name"]; 
		echo "<br><b>Birthdate</b><br>";
		echo $row["member_birthdate"]; 
		echo "<br><b>Gender</b><br>";
		echo $row["member_gender"]; 
		 }
		?>
			
	
	</div>
	
</div>


</body>
</html>