<?php

$connect= mysqli_connect("localhost","root","","nikemember");// fill out database name

?>