<?php

echo "<p><a href='member_add.php'>Add Member</a></p>";
echo "<p><a href='member_list(view_details).php'>Member List (with details only)</a></p>";
echo "<p><a href='member_list(edit).php'>Member List(with edit)</a></p>";
echo "<p><a href='member_list(delete).php'>Member List(with delete)</a></p>";


?>