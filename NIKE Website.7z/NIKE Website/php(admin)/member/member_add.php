<!DOCTYPE html>

<html>
<head><title>Add New Member</title>
<link href="nikememberdesign.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="../phpmain.css" />
</head>
<body>
<?php include '../phpmain.php'; ?>
<div id="wrapper">

	<div id="left">
		<?php include("nikemembermenu.php"); ?>
	</div>
	
	<div id="right">

		<h1>Insert New Member</h1>

		<form name="addfrm" method="post" action="">

			<p><label>Email:</label><input type="text" name="member_email" size="80">
			<p><label>Name:</label><input type="text" name="member_name" size="80">
			<p><label>Birthdate:</label><input type="date" name="member_birthdate" size="80">
			<p><label>Gender: </label><input type="" name="member_gender" size="80" placeholder="Male/Female">
			<p><input type="submit" name="savebtn" value="SAVE MEMBER">

		</form>
	
	</div>
	
</div>


</body>
</html>

<?php
include ("dataconnectionnikemember.php"); 
if(isset($_POST["savebtn"])) 	
{
	$mememail = $_POST["member_email"];
	$memname = $_POST["member_name"];  
	$membirthdate = $_POST["member_birthdate"];  
	$memgender = $_POST["member_gender"];    
	
	$query="INSERT INTO member(member_email,member_name,member_birthdate,member_gender)
	VALUES('$mememail','$memname','$membirthdate','$memgender')";
	
	$abc=mysqli_query($connect,$query);
	if(!$abc)
		die('Could not insert data:'.mysqli_error($connect));
	else
		echo "Member saved";
	
	mysqli_close($connect);
	
	?>
	
		<script type="text/javascript">
			alert("<?php echo $memname. ' saved.'; ?>");
		</script>
	
	<?php
	
	
}

?>