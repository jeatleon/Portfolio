<html>
<head>
	<title>Member List</title>
<link href="nikememberdesign.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="../phpmain.css" />
</head>
<body>
<?php include '../phpmain.php'; ?>

<div id="wrapper">

	<div id="left">
		<?php include("nikemembermenu.php"); ?>
	</div>
	
	<div id="right">

		<h1>Member List</h1>

		<table border="1">
			<tr>
				<th>Member ID</th>
				<th>Member Email</th>
				<th>Member Name</th>
				<th>Member Birthdate</th>
				<th>Member Gender</th>
				<th colspan="2">Action</th>
			</tr>
			
			
			<?php
			include ("dataconnectionnikemember.php");
			$query = "SELECT * FROM member";
			$result = mysqli_query($connect, $query);	
			
			$count = mysqli_num_rows($result);
			
			while($row = mysqli_fetch_assoc($result))
			{
			
			?>			

			<tr>
				<td><?php echo $row["member_id"]; ?></td>
				<td><?php echo $row["member_email"]; ?></td>
				<td><?php echo $row["member_name"]; ?></td>
				<td><?php echo $row["member_birthdate"]; ?></td>
				<td><?php echo $row["member_gender"]; ?></td>
				<td><a href="nikemember_detail.php?view&memid=<?php echo $row["member_id"]; ?>">More Details</a></td>
				<td><a href="member_edit.php?edit&memid=<?php echo $row["member_id"]; ?>">Edit</a></td>
				
			</tr>
			<?php
			
			}
			mysqli_close($connect);
			?>
			
		</table>


		<p> Number of records : <?php echo $count; ?></p>

	</div>
	
</div>


</body>
</html>