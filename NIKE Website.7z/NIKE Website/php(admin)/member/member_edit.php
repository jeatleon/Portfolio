<html>
<head><title>Edit Member</title>
<link href="nikememberdesign.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="../phpmain.css" />
</head>
<body>
<?php include '../phpmain.php'; ?>
<div id="wrapper">

	<div id="left">
		<?php include("nikemembermenu.php"); ?>
	</div>
	
	<div id="right">

		<?php
		if(isset($_GET["edit"]))
		{
			include ("dataconnectionnikemember.php");
			$memid = $_GET["memid"];
			$query = "SELECT * FROM member WHERE member_id = $memid";
			$result = mysqli_query($connect, $query);
			$row = mysqli_fetch_assoc($result);
		?>
		
		<h1>Edit Member</h1>

		<form name="addfrm" method="post" action="">

			<p>Eamil:<input type="text" name="member_email" size="80" value="<?php echo $row['member_email']; ?>">
			<p>Name:<input type="text" name="member_name" size="80" value="<?php echo $row['member_name']; ?>">
			<p>Birthdate:<input type="int" name="member_birthdate" size="80" value="<?php echo $row['member_birthdate']; ?>">
			<p>Gender:<input type="text" name="member_gender" size="80" value="<?php echo $row['member_gender']; ?>">
			
			<p><input type="submit" name="savebtn" value="UPDATE MEMBER">

		</form>
	    <?php 
		}
		  ?>
	</div>
	
</div>


</body>
</html>

<?php

if(isset($_POST["savebtn"])) 	
{
    $mememail = $_POST["member_email"];  		 
	$memname = $_POST["member_name"];  
	$membirthdate = $_POST["member_birthdate"];  
	$memgender = $_POST["member_gender"];  
	
	$query="UPDATE member SET member_email='$mememail', member_name='$memname', member_birthdate='$membirthdate', member_gender='$memgender'
	WHERE member_id=$memid";
	$result = mysqli_query($connect, $query);
?>

<script>
 alert("Updated");
</script>
	
<?php	
	header( "refresh:0.5; url=member_list(edit).php" );
	
}

?>