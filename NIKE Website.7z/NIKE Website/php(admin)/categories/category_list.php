<html>
<head><title>Categories List</title>
<link href="categoriesdesign.css" type="text/css" rel="stylesheet" />

<script type="text/javascript">

//create a javascript function named confirmation()
function confirmation(name)
{
	var answer;
	answer = confirm("Do you want to delete "+name+"?");//put "+title+" use to call title and because is javascript use ++ to call
	return answer;
}
</script>


</head>
<body>

<div id="wrapper">

	<div id="left">
		<?php include("categoriesmenu.php"); ?>
	</div>
	
	<div id="right">

		<h1>Categories List</h1>

		<table border="1">
			<tr>
				<th>Category ID</th>
				<th>Category Name</th>
				<th colspan="3">Action</th>
			</tr>
			
			<?php
			include ("dataconnectioncategories.php");
			$query = "SELECT * FROM category";
			$result = mysqli_query($connect, $query);	
			
			$count = mysqli_num_rows($result);//used to count number of rows
			
			while($row = mysqli_fetch_assoc($result))
			{
				
			?>			
				<?php $name = $row['category_name'];?>
			<tr>
				<td><?php echo $row["category_id"]; ?></td>
				<td><?php echo $row["category_name"]; ?></td>
				<td><a href="categories_detail.php?view&cateid=<?php echo $row["category_id"]; ?>">More Details</a></td>
				<td><a href="category_edit.php?edit&cateid=<?php echo $row["category_id"]; ?>">Edit</a></td>
				<td><a href="category_list(delete).php?del&cateid=<?php echo $row["category_id"]; ?>" 
				onclick="return confirmation('<?php echo $name;?>');">Delete</a></td><!-- call funtion and pass parameter -->
			
			</tr>
			<?php
			
			}
			
			?>
			
		</table>


		<p> Number of records : <?php echo $count; ?></p>

	</div>
	
</div>


</body>
</html>
<?php

if (isset($_GET["del"])) 
{
	$cateid=$_GET["cateid"];
	
	$query="DELETE FROM category WHERE category_id = $cateid";
	mysqli_query($connect,$query);
	
	header("Location: category_list.php"); //refresh the page
}

mysqli_close($connect);
?>