<html>
<head><title>Edit Category</title>
<link href="categoriesdesign.css" type="text/css" rel="stylesheet" />
</head>
<body>

<div id="wrapper">

	<div id="left">
		<?php include("categoriesmenu.php"); ?>
	</div>
	
	<div id="right">

		<?php
		if(isset($_GET["edit"]))
		{
			include ("dataconnectioncategories.php");
			$cateid = $_GET["cateid"];
			$query = "SELECT * FROM category WHERE category_id = $cateid";
			$result = mysqli_query($connect, $query);
			$row = mysqli_fetch_assoc($result);
		?>
		
		<h1>Edit Categories</h1>

		<form name="addfrm" method="post" action="">

			<p>Category:<input type="text" name="category_name" size="80" value="<?php echo $row['category_name']; ?>">
			
			<p><input type="submit" name="savebtn" value="UPDATE CATEGORIES">

		</form>
	    <?php 
		}
		  ?>
	</div>
	
</div>


</body>
</html>

<?php

if(isset($_POST["savebtn"])) 	
{  		 
	$categoryname = $_POST["member_name"];  

	$query="UPDATE category SET category_name='$categoryname' WHERE category_name=$categoryname";
	$result = mysqli_query($connect, $query);
?>

<script>
 alert("Updated");
</script>
	
<?php	
	header( "refresh:0.5; url=category(edit).php" );
	
}

?>