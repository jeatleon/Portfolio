<!DOCTYPE html>

<html>
<head><title>Add New Category</title>
<link href="categoriesdesign.css" type="text/css" rel="stylesheet" />
</head>
<body>

<div id="wrapper">

	<div id="left">
		<?php include("categoriesmenu.php"); ?>
	</div>
	
	<div id="right">

		<h1>Insert New Category</h1>

		<form name="addfrm" method="post" action="">

			<p><label>Category:</label><input type="text" name="category_name" size="80">
			<p><input type="submit" name="savebtn" value="ADD CATEGORY">

		</form>
	
	</div>
	
</div>


</body>
</html>

<?php
include ("dataconnectioncategories.php"); 
if(isset($_POST["savebtn"])) 	
{
	$catename = $_POST["category_name"];    
	
	$query="INSERT INTO category(category_name)VALUES('$catename')";
	
	$abc=mysqli_query($connect,$query);
	if(!$abc)
		die('Could not insert data:'.mysqli_error($connect));
	else
		echo "Category saved";
	
	mysqli_close($connect);
	
	?>
	
		<script type="text/javascript">
			alert("<?php echo $catename. ' saved.'; ?>");
		</script>
	
	<?php
	
	
}

?>