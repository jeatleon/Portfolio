<?php

echo "<p><a href='category_add.php'>Add Category</a></p>";
echo "<p><a href='category_list.php'>Categories List</a></p>";


?>