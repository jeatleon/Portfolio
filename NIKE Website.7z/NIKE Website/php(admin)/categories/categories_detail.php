<html>
<head><title>Categories Detail</title>
<link href="categoriesdesign.css" type="text/css" rel="stylesheet" />
</head>
<body>

<div id="wrapper">

	<div id="left">
		<?php include("categoriesmenu.php"); ?>
	</div>
	
	<div id="right">

		<h1>Categories Details</h1>

		<?php
		include ("dataconnectioncategories.php");
		 if(isset($_GET['view']))
		{
			$cateid = $_GET["cateid"];
			$query = "SELECT * FROM category WHERE category_id = $cateid";
			$result = mysqli_query($connect, $query);
			$row = mysqli_fetch_assoc($result);
		
		echo "<br><b>ID</b><br>";
		echo $row["category_id"]; 
		echo "<br><b>Name</b><br>";
		echo $row["category_name"]; 
		 }
		?>
			
	
	</div>
	
</div>


</body>
</html>