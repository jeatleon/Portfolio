<?php

$connect= mysqli_connect("localhost","root","","categories");// fill out database name

?>