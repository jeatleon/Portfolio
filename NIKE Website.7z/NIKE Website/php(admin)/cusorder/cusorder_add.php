<html>
<head><title>Add New Order</title>
<link href="cusordersdesign.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="../phpmain.css" />
</head>
<body>
<?php include '../phpmain.php'; ?>
<div id="wrapper">

	<div id="left">
		<?php include("cusordersmenu.php"); ?>
	</div>
	
	<div id="right">

		<h1>Insert New Order</h1>

		<form name="addfrm" method="post" action="">

			<p><label>Name:</label><input type="text" name="cusorder_name" size="80">
			<p><label>Price:</label><input type="int" name="cusorder_price" size="80">
			<p><label>Size:</label><input type="int" name="cusorder_size" size="80">
			<p><label>Quantity:</label><input type="text" name="cusorder_quantity" size="80">
			<p><input type="submit" name="savebtn" value="SAVE ORDER">

		</form>
	
	</div>
	
</div>


</body>
</html>

<?php
include ("dataconnectioncusorders.php"); 
if(isset($_POST["savebtn"])) 	
{
	$ordname = $_POST["cusorder_name"];  
	$ordsize = $_POST["cusorder_size"];  
	$ordprice = $_POST["cusorder_price"];  
	$ordquantity = $_POST["cusorder_quantity"];    
	
	$query="INSERT INTO cusorder(cusorder_name,cusorder_price,cusorder_size,cusorder_quantity)
	VALUES('$ordname','$ordprice','$ordsize','$ordquantity')";
	
	$abc=mysqli_query($connect,$query);
	if(!$abc)
		die('Could not insert data:'.mysqli_error($connect));
	else
		echo "Member saved";
	
	mysqli_close($connect);
	
	?>
	
		<script type="text/javascript">
			alert("<?php echo $ordname. ' saved.'; ?>");
		</script>
	
	<?php
	
	
}

?>