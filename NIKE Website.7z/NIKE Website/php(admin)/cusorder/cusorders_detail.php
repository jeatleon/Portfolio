<html>
<head><title>Order Detail</title>
<link href="cusordersdesign.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="../phpmain.css" />
</head>
<body>
<?php include '../phpmain.php'; ?>
<div id="wrapper">

	<div id="left">
		<?php include("cusordersmenu.php"); ?>
	</div>
	
	<div id="right">

		<h1>Order Details</h1>

		<?php
		include ("dataconnectioncusorders.php");
		 if(isset($_GET['view']))
		{
			$ordid = $_GET["ordid"];
			$query = "SELECT * FROM cusorder WHERE cusorder_id = $ordid";
			$result = mysqli_query($connect, $query);
			$row = mysqli_fetch_assoc($result);
		
		echo "<br><b>ID</b><br>";
		echo $row["cusorder_id"]; 
		echo "<br><b>Name</b><br>";
		echo $row["cusorder_name"]; 
		echo "<br><b>Price</b><br>";
		echo $row["cusorder_price"]; 
		echo "<br><b>Size</b><br>";
		echo $row["cusorder_size"]; 
		echo "<br><b>Quantity</b><br>";
		echo $row["cusorder_quantity"]; 
		
		 }
		?>
			
	
	</div>
	
</div>


</body>
</html>