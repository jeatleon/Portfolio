<html>
<head><title>Order List</title>
<link href="cusordersdesign.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="../phpmain.css" />
<script type="text/javascript">

//create a javascript function named confirmation()
function confirmation(name)
{
	var answer;
	answer = confirm("Do you want to delete "+name+"?");//put "+title+" use to call title and because is javascript use ++ to call
	return answer;
}
</script>


</head>
<body>
<?php include '../phpmain.php'; ?>
<div id="wrapper">

	<div id="left">
		<?php include("cusordersmenu.php"); ?>
	</div>
	
	<div id="right">

		<h1>Orders List</h1>

		<table border="1">
			<tr>
				<th>Orders ID</th>
				<th>Shoe Name</th>
				<th>Shoe Price</th>
				<th>Shoe Size</th>
				<th>Shoe Quantity</th>
				<th colspan="3">Action</th>
			</tr>
			
			<?php
			include ("dataconnectioncusorders.php");
			$query = "SELECT * FROM cusorder";
			$result = mysqli_query($connect, $query);	
			
			$count = mysqli_num_rows($result);//used to count number of rows
			
			while($row = mysqli_fetch_assoc($result))
			{
				
			?>			
				<?php $name = $row['cusorder_name'];?>
			<tr>
				<td><?php echo $row["cusorder_id"]; ?></td>
				<td><?php echo $row["cusorder_name"]; ?></td>
				<td><?php echo $row["cusorder_price"]; ?></td>
				<td><?php echo $row["cusorder_size"]; ?></td>
				<td><?php echo $row["cusorder_quantity"]; ?></td>
				<td><a href="cusorders_detail.php?view&ordid=<?php echo $row["cusorder_id"]; ?>">More Details</a></td>
				<td><a href="cusorder_edit.php?edit&ordid=<?php echo $row["cusorder_id"]; ?>">Edit</a></td>
				<td><a href="cusorder_list.php?del&ordid=<?php echo $row["cusorder_id"]; ?>" 
				onclick="return confirmation('<?php echo $name;?>');">Delete</a></td><!-- call funtion and pass parameter -->
			
			</tr>
			<?php
			
			}
			
			?>
			
		</table>


		<p> Number of records : <?php echo $count; ?></p>

	</div>
	
</div>


</body>
</html>
<?php

if (isset($_GET["del"])) 
{
	$ordid=$_GET["ordid"];
	
	$query="DELETE FROM cusorder WHERE cusorder_id = $ordid";
	mysqli_query($connect,$query);
	
	header("Location: cusorder_list.php"); //refresh the page
}

mysqli_close($connect);
?>