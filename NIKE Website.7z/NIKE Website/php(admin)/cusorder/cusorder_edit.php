<html>
	<head>
		<title>Edit Order</title>
		<link href="cusordersdesign.css" type="text/css" rel="stylesheet" />
		<link rel="stylesheet" href="../phpmain.css" />
	</head>
	<body>
		<?php include '../phpmain.php'; ?>
		<div id="wrapper">

			<div id="left">
				<?php include("cusordersmenu.php"); ?>
			</div>
			
			<div id="right">

				<?php
				if(isset($_GET["edit"]))
				{
					include ("dataconnectioncusorders.php");
					$ordid = $_GET["ordid"];
					$query = "SELECT * FROM cusorder WHERE cusorder_id = $ordid";
					$result = mysqli_query($connect, $query);
					$row = mysqli_fetch_assoc($result);
				?>
				
				<h1>Edit Order</h1>

				<form name="addfrm" method="post" action="">

					<p>Name:<input type="text" name="order_name" size="80" value="<?php echo $row['cusorder_name']; ?>">
					<p>Price:<input type="text" name="order_price" size="80" value="<?php echo $row['cusorder_price']; ?>">
					<p>Size:<input type="int" name="order_size" size="80" value="<?php echo $row['cusorder_size']; ?>">
					<p>Quantity:<input type="text" name="order_quantity" size="80" value="<?php echo $row['cusorder_quantity']; ?>">
					
					<p><input type="submit" name="savebtn" value="UPDATE ORDER">

				</form>
				<?php 
				}
				?>
			</div>
			
		</div>
	</body>
</html>

<?php

if(isset($_POST["savebtn"])) 	
{
    $oname = $_POST["order_name"];  	
	$oprice = $_POST["order_price"];  	 
	$osize = $_POST["order_size"];  	 
	$oqty = $_POST["order_quantity"];  	 
	
	$query="UPDATE cusorder SET cusorder_name='$oname',cusorder_price='$oprice',cusorder_size='$osize',cusorder_quantity='$oqty' WHERE cusorder_id=$ordid";
	$result = mysqli_query($connect, $query);
?>

<script>
 alert("Updated");
</script>
	
<?php	
	header( "refresh:0.5; url=cusorder_list.php" );
	
}

?>
