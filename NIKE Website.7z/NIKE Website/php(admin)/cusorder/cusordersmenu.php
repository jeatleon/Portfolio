<?php

echo "<p><a href='cusorder_add.php'>Add Order</a></p>";
echo "<p><a href='cusorder_list.php'>Order List</a></p>";
echo "<p><a href='cusorder_total.php'>Total Order</a></p>";


?>