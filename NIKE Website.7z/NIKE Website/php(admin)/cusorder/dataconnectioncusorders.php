<?php

$connect= mysqli_connect("localhost","root","","cusorders");// fill out database name

?>