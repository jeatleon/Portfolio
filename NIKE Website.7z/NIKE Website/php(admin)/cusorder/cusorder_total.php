<html>
<head><title>Order List</title>
<link href="cusordersdesign.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="../phpmain.css" />

</head>
<body>
<?php include '../phpmain.php'; ?>
<div id="wrapper">

	<div id="left">
		<?php include("cusordersmenu.php"); ?>
	</div>
	
	<div id="right">

		<h1>Orders List</h1>

		<table border="1">
			<tr>
				<th>Orders ID</th>
				<th>Shoe Name</th>
				<th>Shoe Price</th>
				<th>Shoe Size</th>
				<th>Shoe Quantity</th>
				<th>Order Total</th>
			</tr>
			
			<?php
			include ("dataconnectioncusorders.php");
			$query = "SELECT * FROM cusorder";
			$result = mysqli_query($connect, $query);	
			
			$count = mysqli_num_rows($result);//used to count number of rows
			
			$all = 0;

			while($row = mysqli_fetch_assoc($result))
			{
				
			?>		
			
			<tr >
				<td><?php echo $row["cusorder_id"]; ?></td>
				<td><?php echo $row["cusorder_name"]; ?></td>
				<td><?php echo $row["cusorder_price"]; ?></td>
				<td><?php echo $row["cusorder_size"]; ?></td>
				<td><?php echo $row["cusorder_quantity"]; ?></td>
				<?php
					$total = ($row["cusorder_price"] * $row["cusorder_quantity"]);
				?>
				<td><?php echo number_format($total, 2); ?></td>
				
			</tr>

			<?php 				
				$all += $total;
			?>
			<?php
			}
		
			?>
			
		</table>

        <p><?php echo"Total All Order: $".number_format($all, 2); ?></p>
		<p> Number of records : <?php echo $count; ?></p>

	</div>
	
</div>


</body>
</html>
