<html>
    <head>
        <meta charset="UTF-8"/>
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />

        <title>DIT project home page</title>

        <link rel="stylesheet" href="./phphome.css" />
        <link rel="stylesheet" href="../phpmain.css" />
        
    </head>
    <body>
        
        <?php include '../phpmain.php'; ?>
    
        <div class="menu">
            <div class="table">
                <div class="product">
                    <a href="../nike/product_list(view_details).php" class="name">Product List</a>
                </div>

                <div class="cusorder">
                    <a href="../cusorder/cusorder_list.php" class="name">Customer Order List</a>
                </div>

                <div class="member">
                    <a href="../member/member_list(view_details).php" class="name">Member List</a>
                </div>

                <div class="staff">
                    <a href="../staff/staff_list(view_details).php" class="name">Staff List</a>
                </div>

            </div>
            </div>
        </div>

    </body>
</html>