<html>
    <head>
        <meta charset="UTF-8"/>
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />

        <title>DIT project home page</title>

        <link rel="stylesheet" href="./phpmain.css" />
        
    </head>
    <body>
        
        <div class="header">
            <div>
                <a href="../home/phphome.php"><h1 class="nike">NIKE</h1></a>
            </div>
            <div>
                <!-- <span class="hi">Hi ###</span> -->
                <a href="#" class="sign">Signout</a>
            </div>
        </div>

        <div class="type">
            <h2>Admin page</h2>
            <a href="../home/phphome.php">Back to home</a>
        </div>


        <div class="bottom">
            <span>@ IWP Group 11</span>
        </div>
    </body>
</html>