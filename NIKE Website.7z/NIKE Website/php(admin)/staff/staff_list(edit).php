<html>
<head><title>Staff List</title>
<link href="nikestaffdesign.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="../phpmain.css" />
</head>
<body>
<?php include '../phpmain.php'; ?>
<div id="wrapper">

	<div id="left">
		<?php include("nikestaffmenu.php"); ?>
	</div>
	
	<div id="right">

		<h1>List</h1>

		<table border="1">
			<tr>
				<th>Nike ID</th>
				<th>Nike Title</th>
				<th>Nike Price</th>
				<th colspan="2">Action</th>
			</tr>
			
			
			<?php
			include ("dataconnectionnikestaff.php");
			$query = "SELECT * FROM staff";
			$result = mysqli_query($connect, $query);	
			
			$count = mysqli_num_rows($result);//used to count number of rows
			
			while($row = mysqli_fetch_assoc($result))
			{
			
			?>			

			<tr>
				<td><?php echo $row["staff_id"]; ?></td>
				<td><?php echo $row["staff_name"]; ?></td>
				<td><a href="nikestaff_detail.php?view&stid=<?php echo $row["staff_id"]; ?>">More Details</a></td>
				<td><a href="staff_edit.php?edit&stid=<?php echo $row["staff_id"]; ?>">Edit</a></td>
				
			</tr>
			<?php
			
			}
			mysqli_close($connect);
			?>
			
		</table>


		<p> Number of records : <?php echo $count; ?></p>

	</div>
	
</div>


</body>
</html>