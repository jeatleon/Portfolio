<!DOCTYPE html>

<html>
<head><title>Add New Staff</title>
<link href="nikestaffdesign.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="../phpmain.css" />
</head>
<body>
<?php include '../phpmain.php'; ?>
<div id="wrapper">

	<div id="left">
		<?php include("nikestaffmenu.php"); ?>
	</div>
	
	<div id="right">

		<h1>Insert New Staff</h1>

		<form name="addfrm" method="post" action="">

			<p><label>Name:</label><input type="text" name="staff_name" size="80">
			<p><input type="submit" name="savebtn" value="SAVE STAFF">

		</form>
	
	</div>
	
</div>


</body>
</html>

<?php
include ("dataconnectionnikestaff.php"); 
if(isset($_POST["savebtn"])) 	
{
	$mname = $_POST["staff_name"];  	 	 	
	
	$query="INSERT INTO staff(staff_name)
	VALUES('$mname')";
	
	$abc=mysqli_query($connect,$query);
	if(!$abc)
		die('Could not insert data:'.mysqli_error($connect));
	else
		echo "Staff saved";
	
	mysqli_close($connect);
	
	?>
	
		<script type="text/javascript">
			alert("<?php echo $mname. ' saved.'; ?>");
		</script>
	
	<?php
	
	
}

?>