<html>
<head><title>Staff Detail</title>
<link href="nikestaffdesign.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="../phpmain.css" />
</head>
<body>
<?php include '../phpmain.php'; ?>
<div id="wrapper">

	<div id="left">
		<?php include("nikestaffmenu.php"); ?>
	</div>
	
	<div id="right">

		<h1>Staff Details</h1>

		<?php
		include ("dataconnectionnikestaff.php");
		 if(isset($_GET['view']))
		{
			$stid = $_GET["stid"];
			$query = "SELECT * FROM staff WHERE staff_id = $stid";
			$result = mysqli_query($connect, $query);
			$row = mysqli_fetch_assoc($result);
		
		echo "<br><b>ID</b><br>";
		echo $row["staff_id"]; 
		echo "<br><b>Name</b><br>";
		echo $row["staff_name"]; 
			
		 }
		?>
			
	
	</div>
	
</div>


</body>
</html>