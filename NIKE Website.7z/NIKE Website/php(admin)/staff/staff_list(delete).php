<html>
<head><title>Staff List</title>
<link href="nikestaffdesign.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="../phpmain.css" />
<script type="text/javascript">

//create a javascript function named confirmation()
function confirmation(name)
{
	var answer;
	answer = confirm("Do you want to delete "+name+"?");//put "+title+" use to call title and because is javascript use ++ to call
	return answer;
}
</script>


</head>
<body>
<?php include '../phpmain.php'; ?>
<div id="wrapper">

	<div id="left">
		<?php include("nikestaffmenu.php"); ?>
	</div>
	
	<div id="right">

		<h1>Staff List</h1>

		<table border="1">
			<tr>
				<th>Product ID</th>
				<th>Product Name</th>
				<th colspan="3">Action</th>
			</tr>
			
			<?php
			include ("dataconnectionnikestaff.php");
			$query = "SELECT * FROM staff";
			$result = mysqli_query($connect, $query);	
			
			$count = mysqli_num_rows($result);//used to count number of rows
			
			while($row = mysqli_fetch_assoc($result))
			{
				
			?>			
				<?php $name = $row['staff_name'];?>
			<tr>
				<td><?php echo $row["staff_id"]; ?></td>
				<td><?php echo $row["staff_name"]; ?></td>
				<td><a href="nikestaff_detail.php?view&stid=<?php echo $row["staff_id"]; ?>">More Details</a></td>
				<td><a href="staff_edit.php?edit&stid=<?php echo $row["staff_id"]; ?>">Edit</a></td>
				<td><a href="staff_list(delete).php?del&stid=<?php echo $row["staff_id"]; ?>" 
				onclick="return confirmation('<?php echo $name;?>');">Delete</a></td><!-- call funtion and pass parameter -->
			
			</tr>
			<?php
			
			}
			
			?>
			
		</table>


		<p> Number of records : <?php echo $count; ?></p>

	</div>
	
</div>


</body>
</html>
<?php

if (isset($_GET["del"])) 
{
	$stid=$_GET["stid"];
	
	$query="DELETE FROM staff WHERE staff_id = $stid";
	mysqli_query($connect,$query);
	
	header("Location: staff_list(delete).php"); //refresh the page
}

mysqli_close($connect);
?>