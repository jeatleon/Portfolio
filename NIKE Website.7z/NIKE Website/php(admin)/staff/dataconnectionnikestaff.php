<?php

$connect= mysqli_connect("localhost","root","","nikestaff");// fill out database name

?>