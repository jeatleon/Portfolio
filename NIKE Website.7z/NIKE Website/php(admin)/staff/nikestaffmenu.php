<?php

echo "<p><a href='staff_add.php'>Add Staff</a></p>";
echo "<p><a href='staff_list(view_details).php'>Staff List (with details only)</a></p>";
echo "<p><a href='staff_list(edit).php'>Staff List(with edit)</a></p>";
echo "<p><a href='staff_list(delete).php'>Staff List(with delete)</a></p>";


?>