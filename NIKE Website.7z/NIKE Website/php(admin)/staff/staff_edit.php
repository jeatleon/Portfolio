<html>
<head><title>Edit Staff</title>
<link href="nikestaffdesign.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="../phpmain.css" />
</head>
<body>
<?php include '../phpmain.php'; ?>
<div id="wrapper">

	<div id="left">
		<?php include("nikestaffmenu.php"); ?>
	</div>
	
	<div id="right">

		<?php
		if(isset($_GET["edit"]))
		{
			include ("dataconnectionnikestaff.php");
			$stid = $_GET["stid"];
			$query = "SELECT * FROM staff WHERE staff_id = $stid";
			$result = mysqli_query($connect, $query);
			$row = mysqli_fetch_assoc($result);
		?>
		
		<h1>Edit Staff</h1>

		<form name="addfrm" method="post" action="">

			<p>Name:<input type="text" name="staff_name" size="80" value="<?php echo $row['staff_name']; ?>">
			
			<p><input type="submit" name="savebtn" value="UPDATE MOVIE">

		</form>
	    <?php 
		}
		  ?>
	</div>
	
</div>


</body>
</html>

<?php

if(isset($_POST["savebtn"])) 	
{
    $mname = $_POST["staff_name"];  		 
	
	$query="UPDATE staff SET staff_name='$mname' WHERE staff_id=$stid";
	$result = mysqli_query($connect, $query);
?>

<script>
 alert("Updated");
</script>
	
<?php	
	header( "refresh:0.5; url=staff_list(edit).php" );
	
}

?>