<?php

$connect= mysqli_connect("localhost","root","","nike");// fill out database name

?>