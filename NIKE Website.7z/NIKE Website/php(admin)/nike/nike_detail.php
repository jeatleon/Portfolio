<?php include ("dataconnectionnike.php"); ?>

<html>
<head><title>Nike Detail</title>
<link href="nikedesign.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="../phpmain.css" />
</head>
<body>
<?php include '../phpmain.php'; ?>
<div id="wrapper">

	<div id="left">
		<?php include("nikemenu.php"); ?>
	</div>
	
	<div id="right">

		<h1>Details of Movie</h1>

		<?php
		// include ("dataconnectionnike.php");
		 if(isset($_GET['view']))
		{
			$proid = $_GET["proid"];
			$query = "SELECT * FROM productlist WHERE product_id = $proid";
			$result = mysqli_query($connect, $query);
			$row = mysqli_fetch_assoc($result);
		
		echo "<br><b>ID</b><br>";
		echo $row["product_id"]; 
		echo "<br><b>Name</b><br>";
		echo $row["product_name"]; 
		echo "<br><b>Nike Price</b><br>";
		echo "RM".number_format($row["product_price"],2);
			
		
		 }
		?>
			
	
	</div>
	
</div>


</body>
</html>