<html>
	<head>
		<title>Edit a Product</title>
		<link href="nikedesign.css" type="text/css" rel="stylesheet" />
		<link rel="stylesheet" href="../phpmain.css" />
	</head>
	<body>
		<?php include '../phpmain.php'; ?>
		<div id="wrapper">

			<div id="left">
				<?php include("nikemenu.php"); ?>
			</div>
			
			<div id="right">

				<?php
				if(isset($_GET["edit"]))
				{
					include ("dataconnectionnike.php");
					$proid = $_GET["proid"];
					$query = "SELECT * FROM productlist WHERE product_id = $proid";
					$result = mysqli_query($connect, $query);
					$row = mysqli_fetch_assoc($result);
				?>
				
				<h1>Edit a Product</h1>

				<form name="addfrm" method="post" action="">

					<p>Name:<input type="text" name="prod_name" size="80" value="<?php echo $row['product_name']; ?>">
				
					<p>Product Price:<input type="text" name="prod_price" size="10" value="<?php echo $row['product_price']; ?>">
					
					<p><input type="submit" name="savebtn" value="UPDATE MOVIE">

				</form>
				<?php 
				}
				?>
			</div>
			
		</div>


	</body>
</html>

<?php

if(isset($_POST["savebtn"])) 	
{
    $mname = $_POST["prod_name"];  	
	$mprice = $_POST["prod_price"];  	 
	
	$query="UPDATE productlist SET product_name='$mname',product_price='$mprice' WHERE product_id=$proid";
	$result = mysqli_query($connect, $query);
?>

<script>
 alert("Updated");
</script>
	
<?php	
	header( "refresh:0.5; url=product_list(edit).php" );
	
}

?>