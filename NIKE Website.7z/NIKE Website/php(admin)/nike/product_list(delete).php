<html>
<head><title>Product List</title>
<link href="nikedesign.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="../phpmain.css" />
<script type="text/javascript">

//create a javascript function named confirmation()
function confirmation(name)
{
	var answer;
	answer = confirm("Do you want to delete "+name+"?");
}
</script>


</head>
<body>
<?php include '../phpmain.php'; ?>
<div id="wrapper">

	<div id="left">
		<?php include("nikemenu.php"); ?>
	</div>
	
	<div id="right">

		<h1>List of Product</h1>

		<table border="1">
			<tr>
				<th>Product ID</th>
				<th>Product Name</th>
				<th>Product Price</th>
				<th colspan="3">Action</th>
			</tr>
			
			
			<?php
			include ("dataconnectionnike.php");
			$query = "SELECT * FROM productlist";
			$result = mysqli_query($connect, $query);	
			
			$count = mysqli_num_rows($result);
			
			while($row = mysqli_fetch_assoc($result))
			{
				
			?>			
				<?php $name = $row['product_name'];?>
			<tr>
				<td><?php echo $row["product_id"]; ?></td>
				<td><?php echo $row["product_name"]; ?></td>
				<td><?php echo $row["product_price"]; ?></td>
				<td><a href="nike_detail.php?view&proid=<?php echo $row["product_id"]; ?>">More Details</a></td>
				<td><a href="product_edit.php?edit&proid=<?php echo $row["product_id"]; ?>">Edit</a></td>
				<td><a href="product_list(delete).php?del&proid=<?php echo $row["product_id"]; ?>" 
				onclick="return confirmation('<?php echo $name;?>');">Delete</a></td>
			
			</tr>
			<?php
			
			}
			
			?>
			
		</table>


		<p> Number of records : <?php echo $count; ?></p>

	</div>
	
</div>


</body>
</html>
<?php

if (isset($_GET["del"])) 
{
	$proid=$_GET["proid"];
	
	$query="DELETE FROM productlist WHERE product_id = $proid";
	mysqli_query($connect,$query);
	
	header("Location: product_list(delete).php");
}

mysqli_close($connect);
?>