<!DOCTYPE html>

<html>
<head><title>Add New Product</title>
<link href="nikedesign.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="../phpmain.css" />

</head>
<body>
<?php include '../phpmain.php'; ?>
<div id="wrapper">

	<div id="left">
		<?php include("nikemenu.php"); ?>
	</div>
	
	<div id="right">

		<h1>Insert New Product</h1>

		<form name="addfrm" method="post" action="">

			<p><label>Name:</label><input type="text" name="prod_name" size="80">
		 
			<p><label>Price:</label><input type="text" name="prod_price" size="10">
			
			<p><input type="submit" name="savebtn" value="SAVE PRODUCT">

		</form>
	
	</div>
	
</div>
<a href="upload.php">UPLOAD IMAGE</a>

</body>
</html>

<?php
include ("dataconnectionnike.php"); 
if(isset($_POST["savebtn"])) 	
{
	$mname = $_POST["prod_name"];  	
	$mprice = $_POST["prod_price"];  	 	
	
	$query="INSERT INTO productlist(product_name, product_price)
	VALUES('$mname','$mprice')";
	
	$abc=mysqli_query($connect,$query);
	if(!$abc)
		die('Could not insert data:'.mysqli_error($connect));
	else
		echo "Product saved";
	
	mysqli_close($connect);
	
	?>
	
		<script type="text/javascript">
			alert("<?php echo $mname. ' saved.'; ?>");
		</script>
	
	<?php
	
	
}

?>