<?php

echo "<p><a href='product_add.php'>Add Product</a></p>";
echo "<p><a href='product_list(view_details).php'>Product List (with details only)</a></p>";
echo "<p><a href='product_list(edit).php'>Product List(with edit)</a></p>";
echo "<p><a href='product_list(delete).php'>Product List(with delete)</a></p>";


?>