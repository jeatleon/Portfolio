<html>
<head><title>Product List</title>
<link href="nikedesign.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="../phpmain.css" />

</head>
<body>
<?php include '../phpmain.php'; ?>
<div id="wrapper">

	<div id="left">
		<?php include("nikemenu.php"); ?>
	</div>
	
	<div id="right">

		<h1>List of Product</h1>

		<table border="1">
			<tr>
				<th>Product ID</th>
				<th>Product Title</th>
				<th>Product Price</th>
				<th colspan="3">Action</th>
			</tr>
			
			<?php
			include ("dataconnectionnike.php");
			$query = "SELECT * FROM productlist";
			$result = mysqli_query($connect, $query);	
			
			$count = mysqli_num_rows($result);
			
			while($row = mysqli_fetch_assoc($result))
			{
			
			?>			

			<tr>
				<td><?php echo $row["product_id"]; ?></td>
				<td><?php echo $row["product_name"]; ?></td>
				<td><?php echo $row["product_price"]; ?></td>
				<td><a href="nike_detail.php?view&proid=<?php echo $row["product_id"]; ?>">More Details</a></td>
				
			</tr>
			<?php
			
			}
			mysqli_close($connect);
			?>
		</table>


		<p> Number of records : <?php echo $count; ?></p>

	</div>
	
</div>


</body>
</html>